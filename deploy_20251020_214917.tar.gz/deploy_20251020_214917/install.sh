#!/bin/bash
# Script de instalación en el servidor

set -e

echo "🚀 INSTALANDO BACKEND EN PRODUCCIÓN..."
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "app.jar" ]; then
    echo "❌ Error: No se encuentra app.jar. Asegúrate de estar en el directorio correcto."
    exit 1
fi

# 1. Verificar .env
if [ ! -f "/opt/sigma/SigmaBack/.env" ]; then
    echo "⚠️  ATENCIÓN: No existe archivo .env"
    echo "📝 Copia .env.example a /opt/sigma/SigmaBack/.env y configúralo:"
    echo ""
    echo "   cp .env.example /opt/sigma/SigmaBack/.env"
    echo "   nano /opt/sigma/SigmaBack/.env"
    echo ""
    read -p "¿Ya configuraste el .env? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        echo "❌ Instalación cancelada. Configura .env primero."
        exit 1
    fi
fi

# 2. Backup de la base de datos
echo "💾 Creando backup de la base de datos..."
mkdir -p /opt/sigma/SigmaBack/backups
docker exec gym-mysql mysqldump -u gymuser -pgympass \
  --routines --triggers --single-transaction --no-tablespaces \
  gymdb | gzip > /opt/sigma/SigmaBack/backups/gymdb_backup_$(date +%Y%m%d_%H%M%S).sql.gz

echo "✅ Backup creado"

# 3. Aplicar migraciones SQL (si existen)
if [ -f "migrations/add_attendance_simple.sql" ]; then
    echo "🔄 Aplicando migraciones de base de datos..."
    docker exec -i gym-mysql mysql -u gymuser -pgympass gymdb << 'SQL'
ALTER TABLE reservations 
  ADD COLUMN IF NOT EXISTS attended TINYINT(1) NOT NULL DEFAULT 0 
  COMMENT 'Indica si el usuario asistió';
ALTER TABLE reservations 
  ADD COLUMN IF NOT EXISTS attended_at DATETIME NULL 
  COMMENT 'Fecha y hora cuando se marcó la asistencia';
CREATE INDEX IF NOT EXISTS idx_reservations_attended_date 
  ON reservations(attended, date);
SQL
    echo "✅ Migraciones aplicadas"
else
    echo "ℹ️  No hay migraciones SQL que aplicar"
fi

# 4. Copiar archivos al directorio de trabajo
echo "📦 Copiando archivos..."
cp -f Dockerfile /opt/sigma/SigmaBack/
cp -f docker-compose.yml /opt/sigma/SigmaBack/
cp -f app.jar /opt/sigma/SigmaBack/target/gym-0.0.1-SNAPSHOT.jar

# 5. Detener contenedor actual
echo "🛑 Deteniendo contenedor actual..."
docker-compose -f /opt/sigma/SigmaBack/docker-compose.yml stop backend || true
docker rm -f gym-backend || true

# 6. Reconstruir imagen
echo "🔨 Reconstruyendo imagen..."
cd /opt/sigma/SigmaBack
docker-compose build --no-cache backend

# 7. Iniciar backend
echo "🚀 Iniciando backend..."
docker-compose up -d backend

# 8. Esperar a que inicie
echo "⏳ Esperando a que el backend inicie..."
sleep 10

# 9. Verificar logs
echo "📋 Logs del backend:"
docker logs gym-backend --tail=30

echo ""
echo "✅ ¡DEPLOY COMPLETADO!"
echo ""
echo "🔍 Verificaciones recomendadas:"
echo "   1. docker ps | grep gym-backend"
echo "   2. docker logs gym-backend -f"
echo "   3. curl http://127.0.0.1:8080/api/auth/login"
echo ""
