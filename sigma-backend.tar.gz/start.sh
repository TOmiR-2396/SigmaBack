#!/bin/bash
echo "🚀 Iniciando SigmaBack..."

# Detener proceso anterior
pkill -f "gym-0.0.1-SNAPSHOT.jar" 2>/dev/null || echo "No hay proceso anterior"

sleep 2

# Iniciar aplicación
nohup java -jar -Dspring.profiles.active=prod gym-0.0.1-SNAPSHOT.jar > app.log 2>&1 &

sleep 5

# Verificar que inició
if pgrep -f "gym-0.0.1-SNAPSHOT.jar" > /dev/null; then
    echo "✅ Aplicación iniciada exitosamente"
    echo "PID: $(pgrep -f gym-0.0.1-SNAPSHOT.jar)"
    echo "Para ver logs: tail -f app.log"
else
    echo "❌ Error al iniciar la aplicación"
    echo "Últimos logs:"
    tail -20 app.log 2>/dev/null || echo "No hay logs"
    exit 1
fi
